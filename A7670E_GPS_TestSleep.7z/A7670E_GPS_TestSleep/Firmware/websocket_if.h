#ifndef WEBSOCKET_IF_H_
#define WEBSOCKET_IF_H_
void ws_task( void );
void ws_service_begin( void );
void ws_sendledvalues( void );
#endif
