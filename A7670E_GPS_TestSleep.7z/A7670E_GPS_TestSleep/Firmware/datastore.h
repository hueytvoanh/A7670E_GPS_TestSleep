#ifndef DATASTORE_H_
 #define DATASTORE_H_
 
#include "timecore.h"
#include "led.h"

typedef struct {
  char ssid[128];
  char pass[128];
} credentials_t;



typedef struct{
  char ntpServerName[129];
  bool NTPEnable;
  int32_t SyncIntervall;
} ntp_config_t;

typedef struct {
  bool enable;
  char mqttservename[129];
  uint16_t mqttserverport;
  char mqttusername[129];
  char mqttpassword[129];
  char mqtttopic[501];
  char mqtthostname[65];
}mqttsettings_t; /*956 byte */


typedef struct{
  uint8_t gpio_value[4];
} gpioState_t;
/**************************************************************************************************
 *    Function      : datastoresetup
 *    Description   : Gets the EEPROM Emulation set up
 *    Input         : none 
 *    Output        : none
 *    Remarks       : We use 4096 byte for EEPROM 
 **************************************************************************************************/
void datastoresetup();

/**************************************************************************************************
 *    Function      : eepread_ledsettings
 *    Description   : reads the mqtt settings
 *    Input         : none
 *    Output        : displaysettings_t
 *    Remarks       : none
 **************************************************************************************************/
ledsettings_t eepread_ledsettings( void );

/**************************************************************************************************
 *    Function      : eepwrite_ledsettings
 *    Description   : write the led settings
 *    Input         : displaysettings_t data
 *    Output        : none
 *    Remarks       : none
 **************************************************************************************************/
void eepwrite_ledsettings(ledsettings_t data);


masterSensor_t eepread_master_config( void );
void eepwrite_master_config(masterSensor_t data);


voltageCurrent_t eepread_voltage_current_config( void );
void eepwrite_voltage_current_config(voltageCurrent_t data);

/**************************************************************************************************
 *    Function      : write_ntp_config
 *    Description   : writes the ntp config
 *    Input         : ntp_config_t c 
 *    Output        : none
 *    Remarks       : none 
 **************************************************************************************************/
void write_ntp_config(ntp_config_t c);


/**************************************************************************************************
 *    Function      : read_ntp_config
 *    Description   : writes the ntp config
 *    Input         : none
 *    Output        : ntp_config_t
 *    Remarks       : none
 **************************************************************************************************/
ntp_config_t read_ntp_config( void );



/**************************************************************************************************
 *    Function      : write_timecoreconf
 *    Description   : writes the time core config
 *    Input         : timecoreconf_t
 *    Output        : none
 *    Remarks       : none
 **************************************************************************************************/
void write_timecoreconf(timecoreconf_t c);


/**************************************************************************************************
 *    Function      : read_timecoreconf
 *    Description   : reads the time core config
 *    Input         : none
 *    Output        : timecoreconf_t
 *    Remarks       : none
 **************************************************************************************************/
timecoreconf_t read_timecoreconf( void );


/**************************************************************************************************
 *    Function      : write_credentials
 *    Description   : writes the wifi credentials
 *    Input         : credentials_t
 *    Output        : none
 *    Remarks       : none
 **************************************************************************************************/
void write_credentials(credentials_t c);


/**************************************************************************************************
 *    Function      : read_credentials
 *    Description   : reads the wifi credentials
 *    Input         : none
 *    Output        : credentials_t
 *    Remarks       : none
 **************************************************************************************************/
credentials_t read_credentials( void );

/**************************************************************************************************
 *    Function      : eepwrite_notes
 *    Description   : writes the user notes 
 *    Input         : uint8_t* data, uint32_t size
 *    Output        : none
 *    Remarks       : none
 **************************************************************************************************/
void eepwrite_notes(uint8_t* data, uint32_t size);

/**************************************************************************************************
 *    Function      : eepread_notes
 *    Description   : reads the user notes 
 *    Input         : uint8_t* data, uint32_t size
 *    Output        : none
 *    Remarks       : none
 **************************************************************************************************/
void eepread_notes(uint8_t* data, uint32_t size);

void eepwrite_MAC1(uint8_t* data, uint32_t size);
void eepread_MAC1(uint8_t* data, uint32_t size);

void eepwrite_MAC2(uint8_t* data, uint32_t size);
void eepread_MAC2(uint8_t* data, uint32_t size);

void eepwrite_MAC3(uint8_t* data, uint32_t size);
void eepread_MAC3(uint8_t* data, uint32_t size);

void eepwrite_MAC4(uint8_t* data, uint32_t size);
void eepread_MAC4(uint8_t* data, uint32_t size);

void eepwrite_MAC5(uint8_t* data, uint32_t size);
void eepread_MAC5(uint8_t* data, uint32_t size);

void eepwrite_MAC6(uint8_t* data, uint32_t size);
void eepread_MAC6(uint8_t* data, uint32_t size);

void eepwrite_timer(uint8_t* data, uint32_t size);
void eepread_timer(uint8_t* data, uint32_t size);

void eepwrite_ledeffect(uint8_t* data, uint32_t size);
void eepread_ledeffect(uint8_t* data, uint32_t size);

void eepwrite_NoOfNode(uint8_t* data, uint32_t size);
void eepread_NoOfNode(uint8_t* data, uint32_t size);

void eepwrite_systemState(uint8_t* data, uint32_t size);
void eepread_systemState(uint8_t* data, uint32_t size);

neoSettings_t eepread_neoSettings( void );
void eepwrite_neoSettings(neoSettings_t data);
/**************************************************************************************************
 *    Function      : eepwrite_mqttsettings
 *    Description   : write the mqtt settings
 *    Input         : mqttsettings_t data
 *    Output        : none
 *    Remarks       : none
 **************************************************************************************************/
void eepwrite_mqttsettings(mqttsettings_t data);

/**************************************************************************************************
 *    Function      : eepread_mqttsettings
 *    Description   : reads the mqtt settings
 *    Input         : none
 *    Output        : mqttsettings_t
 *    Remarks       : none
 **************************************************************************************************/
mqttsettings_t eepread_mqttsettings( void );

/**************************************************************************************************
 *    Function      : erase_eeprom
 *    Description   : writes the whole EEPROM with 0xFF  
 *    Input         : none
 *    Output        : none
 *    Remarks       : This will invalidate all user data 
 **************************************************************************************************/
void erase_eeprom( void );

void eepwrite_gpiosettings(gpioState_t data);
gpioState_t eepread_gpiosettings( void );
#endif
